package studio.crunchyiee.sampleapp.Model

data class NavMenu(val id: Int, val name: String) {

}
